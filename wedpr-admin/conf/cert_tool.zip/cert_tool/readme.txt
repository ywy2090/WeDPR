1.解压cert_tool.zip文件，在linux安装openssl 1.1.1，然后执行相关命令。

2.管理端生成根证书：将ca目录下的文件ca.crt  ca.key放置到管理端服务conf/cert/root目录下
# bash cert_script.sh gen_chain_cert ca

3.站点端生成机构证书请求文件：生成的agency.csr在给定的机构名目录下
# bash cert_script.sh gen_rsa_req agency  $机构名

4.将生成的agency.csr文件在管理端页面上传，用于生成机构证书文件